<?php 
$nik = "BISMILLAH GG";
$sender = "kimberlyhimeku@gmail.com";
?>